int writePipe(int fd, char msg);
int writeFile(char *name, int fd);
